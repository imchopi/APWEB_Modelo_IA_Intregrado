import numpy as np

class Neuron:
    def __init__(self, num_entradas, learning_rate=0.2):
        """
        Inicializa los pesos, el sesgo y la tasa de aprendizaje.
        """
        self.pesos = np.random.rand(num_entradas)  # Pesos inicializados aleatoriamente
        self.sesgo = np.random.rand()             # Sesgo inicial aleatorio
        self.learning_rate = learning_rate        # Velocidad de aprendizaje

    def binary_step(self, x):
        """
        Función de activación: Binary Step.
        Devuelve 1 si x >= 0, de lo contrario devuelve 0.
        """
        return 1 if x >= 0 else 0

    def calcular_salida(self, entradas):
        """
        Calcula la salida de la neurona para las entradas dadas.
        """
        suma = np.dot(entradas, self.pesos) + self.sesgo  # Producto punto + sesgo
        return self.binary_step(suma)

    def calcular_error(self, entradas, salida_deseada):
        """
        Entrena la neurona para un conjunto de entradas y salida deseada.
        Ajusta los pesos y el sesgo según el error.
        """
        salida_obtenida = self.calcular_salida(entradas)  # Calcula la salida actual
        error = salida_deseada - salida_obtenida         # Calcula el error
        self.sesgo += self.learning_rate * error         # Ajusta el sesgo
        self.pesos += self.learning_rate * error * np.array(entradas)  # Ajusta los pesos
        return error
