from neuron import Neuron
import numpy as np

# Datos de entrenamiento (entradas y salidas deseadas)
datos_entrenamiento = [
    (np.array([0, 0]), 0),
    (np.array([0, 1]), 0),
    (np.array([1, 0]), 0),
    (np.array([1, 1]), 1)
]

# Crear una neurona con 2 entradas
neuron = Neuron(num_entradas=2, learning_rate=0.2)

# Entrenar la neurona
error_aceptable = 0.01
for epoch in range(10000):  # Número máximo de épocas
    total_error = 0
    for entradas, salida_deseada in datos_entrenamiento:
        error = neuron.calcular_error(entradas, salida_deseada)
        total_error += abs(error)
    if total_error / len(datos_entrenamiento) < error_aceptable:
        break

# Probar la neurona entrenada
for entradas, salida_deseada in datos_entrenamiento:
    salida_obtenida = neuron.calcular_salida(entradas)
    print(f"Entradas: {entradas}, Salida deseada: {salida_deseada}, Salida obtenida: {salida_obtenida}")